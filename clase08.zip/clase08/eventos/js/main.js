if(localStorage.login=="1"){
		window.location="./listado.html"
}


let btn=document.getElementById('login-usuario');

let elemento=document.getElementById('alert-error');
let intentos=0;

btn.addEventListener("click",tarea)
function tarea(){

	//event.preventDefault();
	//console.log("hizo click");
	let usuario=document.getElementById('inp-usuario').value;
	let password=document.getElementById('inp-password').value;
	/*
	usuario="    jc";
	usuario.trim() // "jc"

	usuario="    jc       ";
	usuario.trim() // "jc"

	usuario="    j       c       ";
	usuario.trim() // "j       c"

	usuario="             "
	usuario.trim() // ""
	*/

	if(intentos==3){
		elemento.innerHTML="<strong>USUARIO BLOQUEADO</strong> comunicate con el administrador";
		elemento.classList.remove("hide")
	}
	else{


		if(usuario.trim()=="" && password.trim()=="")
		{
			elemento.innerHTML="<strong>Ingresa</strong> valores para empezar"
			elemento.classList.remove("hide")
			
		}
		else{
			validarDatos(usuario.trim(),password.trim());

		}


	}
	/*
	==  // evalua valores
	===  // valores y tipos

	1=="1"  // true
	1==="1" // false
	*/
	


}


function validarDatos(usuario,password){

if(usuario=="admin" && password=="123"){
		
		elemento.classList.add("hide") ;
		window.location="./listado.html"
		localStorage.login=1;
		}
		else{
			//console.log("datos incorrectos");
	
			//elemento.classList.add() // agregar clases
			elemento.innerHTML="Valores ingresados <strong>no son correctos</strong>";
			elemento.classList.remove("hide") // remover clases
			intentos++;

		}
}