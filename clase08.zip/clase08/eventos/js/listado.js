
let objeto3={
	nombre:"Martin",
	apellido:"Luna"}


let lista_elmentos=[
					{nombre:"juancarlos",apellido:"Ramos"},
					{nombre:"diego",apellido:"Perez"},
					objeto3];
/*
console.log(lista_elmentos)

console.log(lista_elmentos[0])
console.log(lista_elmentos[1])
console.log(lista_elmentos[2])
console.log(lista_elmentos[3])*/
let limite=lista_elmentos.length;
let lista=document.getElementById('listado');
let temporal="";
for(let i=0;i<limite;i++){
	console.log(lista_elmentos[i].nombre);
	/*temporal=temporal+'<li  class="list-group-item" onclick="ver_detalle()" >
						+lista_elmentos[i].nombre+
						'<strong></strong>'
						</li>';*/
	
	temporal=temporal+`<li  class="list-group-item" onclick="ver_detalle('${lista_elmentos[i].apellido}')">
						${lista_elmentos[i].nombre} ${lista_elmentos[i].apellido}
						<a href=""></a>
						</li>`
}


lista.innerHTML=temporal;

//document.getElementById('#item1')

function ver_detalle(apellido){
	console.log(apellido);
document.getElementById('detalle').innerText=`El apellido del usuario seleccionado es: ${apellido}`;
}