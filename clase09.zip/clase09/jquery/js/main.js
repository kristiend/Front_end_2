console.log("hola");

/*let elemento=document.getElementById('title-site')
elemento.classList.add("activado");
elemento.classList.remove("activado");*/

/*$("#title-site").addClass("activado");
$("#title-site").removeClass("activado");*/


$("#cambiar").click(function (){
	$("#title-site").text("Texto modificado por JS")
})


/*
$("#cambiar").click(()=>{


})
*/

