  // Your web app's Firebase configuration
  var firebaseConfig = {
    apiKey: "AIzaSyAXSzhWTBStIuFgVWHImkOU__iOqN0ltqk",
    authDomain: "chatn2.firebaseapp.com",
    databaseURL: "https://chatn2.firebaseio.com",
    projectId: "chatn2",
    storageBucket: "",
    messagingSenderId: "52156700634",
    appId: "1:52156700634:web:1cdd29e5c04602c2"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);