class Usuario{
	constructor(valor1,valor2){
		this.nombre=valor1;
		this.apellido=valor2;
	}
	obtenerNombre(){
		console.log(this.nombre+" "+this.apellido);
	}

	
}

class Utilitarios{
	constructor(){

	}
	static horaActual(){
		console.log("mostrando la hora actual");
	}
	
}