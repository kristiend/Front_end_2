let obj=new Usuario("Juan Carlos","Ramos");

obj.obtenerNombre();


Utilitarios.horaActual();
/*let mat=new Math()
mat.max()*/
Math.max()
Math.min()