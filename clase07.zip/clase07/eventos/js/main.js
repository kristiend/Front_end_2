let btn_cambiar;
let btn_regresar;
let titulo;
// 1 solo elemento
btn_cambiar=document.getElementById('cambiar');
btn_cambiar.addEventListener("click",tarea)

function tarea(){
	//console.log("hizo click");
	titulo=document.getElementById("title");
	titulo.innerHTML="Título agregado desde JS";
	titulo.classList.add("activo");
	//titulo.classList.remove()
	/*titulo.style.color="red";
	titulo.style.fontSize="12px";
	titulo.style.backgroundColor="black";*/

}


// todos los elementos con ese tag
//document.getElementsByTag('')

// todos los elementos con ese clase
//document.getElementsByClassName('')
btn_regresar=document.getElementById("regresar");
btn_regresar.addEventListener("click",regresar_titulo)
function regresar_titulo(){
	titulo=document.getElementById("title");
	titulo.innerHTML="Título creado en html";
	titulo.classList.remove("activo");
}