
if(localStorage.login=="true"){
	window.location="./listado.html";
}

let ingresar=document.getElementById('btn-ingresar');
ingresar.addEventListener("click",validacion)

function validacion(){
	//console.log("hizo click");
	let usuario=document.getElementById("inp-usuario").value;
	let password=document.getElementById("inp-password").value;
	console.log(usuario)
	console.log(password)
	//1=="1" v
	//1==="1" f

	/*if(usuario=="admin" && password=="123"){
		console.log("datos ingresados son correctos")
		window.location="./listado.html";
	}
	else{
		//console.log("revisar tus datos")
		let mensajeError=document.getElementById("mensaje-error");
		mensajeError.classList.remove("hide");
	}*/

	let resultadoValidacion=validarDatosServicio(usuario,password);
	if(resultadoValidacion){
		window.location="./listado.html";
	}
	else{
		let mensajeError=document.getElementById("mensaje-error");
		mensajeError.classList.remove("hide");
	}
	/*
	if(usuario=="admin"){
		console.log("usuario correcto");
	}
	else{
		console.log("usuario incorrecto");
	}*/
	/*
	if(a>b){

	}
	else if(a>c){
	}
	else{

	}*/
	/*
	if(condicion){

	}
	else{

	}*/
}


function validarDatosServicio(user,password){
	// conectate a un webserivice
	let estado=false;
	if(user=="admin" && password=="123"){
		estado=true;
		localStorage.login="true";
	}

	else{
		estado=false;
	}

	return estado;
}