//console.log("mensaje enviado desde js");

var nombre;
var apellido;
nombre="Juan Carlos";
apellido=nombre;  // "nombre"

console.log("mensaje desde javascript");
console.log("nombre"); //
console.log(nombre); // 

var edad;
edad=20;
//var dato3;
//var dato3
var dato3;
dato3="texto nuevo";
console.log(dato3);

var dato4="DIEGO";
console.log(dato4);

// variable boolena
var dato5=true;
var dato5=false;
var dato6=null;
 // valor true = distinto a 0
 // valor false = 0 , null , nan , undifined
var nombre="Front End";
console.log(nombre);

// evita sobreescritura de variable
let num1=10;
// evita sobreescritura de variable + no se puede
// reasignar el valor de la variable
const num2=3.50;
//num2=340;


// fecha
let fecha="26/06/2019";
let nueva_fecha=new Date();
console.log(fecha);
console.log(nueva_fecha);

console.log(nueva_fecha.getFullYear()) // 2019
console.log(nueva_fecha.getMonth()) // 05
console.log(nueva_fecha.getDate()) // 26
console.log(nueva_fecha.getDay()) // 3
console.log(nueva_fecha.getHours()) // cada hora
console.log(nueva_fecha.getMinutes()) // cada minuto
console.log(nueva_fecha.getSeconds()) // cada segundo

//let fecha_formato="10" + "20"; // "1020"


let fecha_formato=nueva_fecha.getDate() + "/"+nueva_fecha.getMonth()+"/"+nueva_fecha.getFullYear(); // "1020"

console.log(fecha_formato);

//           1     2     3   4     5
let lista=["jc","diego",12,true,"María",true]
//           0      1    2    3    4  

let cantidad=lista.length;
console.log(cantidad);
let ultimo=cantidad-1;
//console.log(lista);
console.log(lista[ultimo]);

let datos=["jc",[20,30,[20,29,09]],true]
console.log(datos[1][2][2])


let datos_usuario=[
					"juan carlos",
					"12300",
					"mañana",
					"asda123wer"
				  ]
let usuario={
	nombre:"Juan Carlos",
	codigo:"12300",
	turno:"mañana",
	password:"asda123wer"
}
usuario.nombre;
usuario.turno;
usuario.password;
usuario.codigo;



let usuario2={
	nombre:"Diego",
	codigo:"12300",
	turno:"mañana",
	password:"asda123wer"
}

let usuario3={
	nombre:"Martín",
	codigo:"12300",
	turno:"mañana",
	password:"asda123wer"
}

let lista_usuarios=[usuario,usuario2,usuario3]

lista_usuarios[0].nombre
lista_usuarios[1].nombre
lista_usuarios[2].nombre









/*
String nombre;
char caracter;
integer num1;

$dato;
*/

