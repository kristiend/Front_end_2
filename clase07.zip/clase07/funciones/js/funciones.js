let num1=prompt("ingresa el primer numero");
let num2=prompt("ingresa el segundo numero");

//let num1_numerico=parseInt(num1)
//let num2_numerico=parseInt(num2);

sumar2(num1,num2);

function sumar2(valor1,valor2){
	 let suma=parseInt(valor1)+parseInt(valor2)
	 console.log(suma);
}


let resultado_suma=sumar3(15,20);

function sumar3(valor1,valor2){
	let suma=valor1+valor2;
	return suma;
}






function suma(){
	// ambito de la funcion
	let num1=10;
	let num2=20;
	let suma=num1+num2;
	console.log(suma);
}
function resta(valor1,valor2){
	// ambito de la funcion
	let resta=valor1-valor2;
	console.log(resta);
}

resta(20,5);
resta(8,5);
resta(33,18);


suma();
// declaracion de funcion
function operacion(){
	// tareas a realizar
}

// asignacion de funcion

let operacion=function(){
	// tareas a realizar
}


// funcion de tipo flecha

let operacion=()=>{
	// tareas a realizar	
}


// parmetro
let igv= valor1 =>{
	// tareas a realizar	
	return valor1*0.18;
}


let igv= valor1 => valor1*0.18;

function igv(valor){
	return valor*0.18;
}



