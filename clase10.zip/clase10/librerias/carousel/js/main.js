$(document).ready(function(){
 let opciones={
 	items:4,
 	margin:10,
 	loop:true,
 	center:false,
 	startPosition:3,
 	autoplay:false,
 	autoplayTimeout:5000,
 	responsive:{
 		0:{
 			items:1
 		},
 		600:{
 			items:2
 		},
 		800:{
 			items:3
 		},
 		1024:{
 			items:4
 		}
 	}
 }


  $(".owl-carousel").owlCarousel(opciones);
});